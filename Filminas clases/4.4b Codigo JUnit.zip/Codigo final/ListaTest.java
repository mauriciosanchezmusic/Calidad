package mx.itesm.demo.cps;

import static org.junit.Assert.*;

import org.junit.Test;

public class ListaTest {

	private double err = 0.000001;

	// Probar las condiciones de una lista vacia
	@Test
	public void testVacio() {
		
		// Crear una lista vacía
		Lista miLista = new Lista();
		
		// La lista debe estar vacia
		assertTrue("La lista debia estar vacia", miLista.Vacio());
		assertEquals("El valor actual debia ser cero", 0, miLista.ValorActual(), err);
		
		// Ir a inicio no debe cambiar nada
		miLista.IrInicio();
		assertTrue("La lista debia estar vacia", miLista.Vacio());
		assertEquals("El valor actual debia ser cero", 0, miLista.ValorActual(), err);
		
		// Moverse al siguiente no debe cambiar nada
		assertFalse("Siguiente debia regresar FALSE", miLista.Siguiente());
		assertTrue("La lista debia estar vacia", miLista.Vacio());
		assertEquals("El valor actual debia ser cero", 0, miLista.ValorActual(), err);
		
		// El promedio debe ser cero
		assertEquals("El promedio debia ser cero", 0, miLista.Promedio(), err);
}

	// Probar las condiciones de una lista con un dato
	@Test
	public void testUno() {

		// Crear una lista con un 8
		Lista miLista = new Lista();
		miLista.AgregaFin(8);
		
		// La lista no debe estar vacia
		assertFalse("La lista no debia estar vacia", miLista.Vacio());
		assertEquals("El valor actual debia ser 8", 8, miLista.ValorActual(), err);
		
		// Ir a inicio no debe cambiar nada
		miLista.IrInicio();
		assertFalse("La lista no debia estar vacia", miLista.Vacio());
		assertEquals("El valor actual debia ser 8", 8, miLista.ValorActual(), err);
		
		// Moverse al siguiente no debe cambiar nada
		assertFalse("Siguiente debia regresar FALSE", miLista.Siguiente());
		assertFalse("La lista no debia estar vacia", miLista.Vacio());
		assertEquals("El valor actual debia ser 8", 8, miLista.ValorActual(), err);

		// El promedio debe ser 8
		assertEquals("El promedio debia ser 8", 8, miLista.Promedio(), err);
}

	// Probar las condiciones de una lista con dos datos
	@Test
	public void testDos() {
		
		// Crear una lista con un 7, 8
		Lista miLista = new Lista();
		miLista.AgregaInicio(8);
		miLista.AgregaInicio(7);
		
		// La lista no debe estar vacia
		assertFalse("La lista no debia estar vacia", miLista.Vacio());
		assertEquals("El valor actual debia ser 7", 7, miLista.ValorActual(), err);
		
		// Moverse al siguiente debe irse al final
		assertTrue("Siguiente debia regresar TRUE", miLista.Siguiente());
		assertFalse("La lista no debia estar vacia", miLista.Vacio());
		assertEquals("El valor actual debia ser 8", 8, miLista.ValorActual(), err);
		
		// Ir a inicio debe regresar al inicio
		miLista.IrInicio();
		assertFalse("La lista no debia estar vacia", miLista.Vacio());
		assertEquals("El valor actual debia ser 7", 7, miLista.ValorActual(), err);
		
		// El promedio debe ser 7.5
		assertEquals("El promedio debia ser 7.5", 7.5, miLista.Promedio(), err);
	}

	// Probar las condiciones de una lista con varios datos
	@Test
	public void testVarios() {
		
		// Crear una lista con 9, 7, 8, 1, 3
		Lista miLista = new Lista();
		miLista.AgregaFin(8);
		miLista.AgregaInicio(7);
		miLista.AgregaInicio(9);
		miLista.AgregaFin(1);
		miLista.AgregaFin(3);
		
		// La lista no debe estar vacia
		assertFalse("La lista no debia estar vacia", miLista.Vacio());
		assertEquals("El valor actual debia ser 3", 3, miLista.ValorActual(), err);
		assertEquals("El promedio debia ser 5.6", 5.6, miLista.Promedio(), err);
		
		// La lista debe tener 9, 7, 8, 1, 3
		miLista.IrInicio();
		double result = miLista.ValorActual();
		while (miLista.Siguiente()) {
			result = result*10 + miLista.ValorActual();
		}
		assertEquals("El valor actual debia ser 97813", 97813, result, err);
	}
}
