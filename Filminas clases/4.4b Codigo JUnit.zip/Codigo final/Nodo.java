package mx.itesm.demo.cps;

public class Nodo {
	
	private double dato; //dato almacenado en el nodo
	private Nodo sig; //apuntador al siguiente nodo
	
	// Constructores
	
	public Nodo() {
		this.dato = 0;
		this.setSig(null);
	}
	
	public Nodo(double dato) {
		this.setDato(dato);
		this.setSig(null);
	}

	// geters y seters
	
	public double getDato() {
		return dato;
	}
	public void setDato(double dato) {
		this.dato = dato;
	}

	public Nodo getSig() {
		return sig;
	}

	public void setSig(Nodo sig) {
		this.sig = sig;
	}
	
}