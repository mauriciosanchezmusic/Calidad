package mx.itesm.demo.cps;

public class Lista {

	private Nodo inicio; //Apunta al primer nodo de la lista, si lista vacía <-- NULO
	private Nodo fin; //Apunta al último nodo de la lista, si lista vacía <-- NULO
	private Nodo actual; //Apunta al nodo en que se está trabajando, si lista vacía <-- NULO

	// constructor... crea una lista vacía
	public Lista() {
	}
	
	// Agrega al final de la lista el valor contenido en “dato”.
	// “actual” apunta al valor insertado.
	public void AgregaFin(double dato){
	}
	
	// Agrega al inicio de la lista el valor contenido en “dato”.
	// “actual” apunta al valor insertado.
	public void AgregaInicio(double dato){
	}
	
	// Mueve “actual” al primer nodo de la lista. 
	// Si la lista está vacía… actual <-- NULO.
	public void IrInicio(){
	}
	
	// Mueve “actual” al siguiente valor en la lista, si puede.
	// Regresa TRUE si lo pudo mover, FALSE si no pudo.
	public boolean Siguiente(){
	}
	
	// Regresa el valor al que apunta “actual”.
	// Si “actual” es NULO, regresa 0 (cero).
	public double ValorActual(){
	}
	
	// Regresa TRUE si la lista está vacía, si no regresa FALSE
	public boolean Vacio(){
	}
	
	// Regresa el promedio de los datos almacenados en la lista.
	// Si la lista está vacía regresa 0 (cero).
	public double Promedio(){
	}
}