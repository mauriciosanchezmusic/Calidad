package mx.itesm.demo.cps;

import static org.junit.Assert.*;

import org.junit.Test;

public class ListaTest {

	// Probar las condiciones de una lista vacia
	@Test
	public void testVacio() {
		
		// Crear una lista vacía
		
		// La lista debe estar vacia
		
		// Ir a inicio no debe cambiar nada
		
		// Moverse al siguiente no debe cambiar nada
		
		// El promedio debe ser cero
}

	// Probar las condiciones de una lista con un dato
	@Test
	public void testUno() {

		// Crear una lista con un 8
		
		// La lista no debe estar vacia
		
		// Ir a inicio no debe cambiar nada
		
		// Moverse al siguiente no debe cambiar nada

		// El promedio debe ser 8
}

	// Probar las condiciones de una lista con dos datos
	@Test
	public void testDos() {
		
		// Crear una lista con un 7, 8
		
		// La lista no debe estar vacia
		
		// Moverse al siguiente debe irse al final
		
		// Ir a inicio debe regresar al inicio
		
		// El promedio debe ser 7.5
	}

	// Probar las condiciones de una lista con varios datos
	@Test
	public void testVarios() {
		
		// Crear una lista con 9, 7, 8, 1, 3
		
		// La lista no debe estar vacia
		
		// La lista debe tener 9, 7, 8, 1, 3
	}
}
